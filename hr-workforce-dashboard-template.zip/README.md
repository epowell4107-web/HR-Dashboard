# HR Workforce Dashboard — Template

A single-file, no-backend dashboard for HR teams to see turnover, compensation, and market
positioning at a glance. Built for residential/direct-care style organizations (shift-based
hourly roles plus a few salaried management titles) but adaptable to any hourly workforce.

This repo ships as a **template with no real data in it** — an empty, working example you fill
in with your own export. Nothing here identifies any real organization or employee.

## What it does

- **Headcount & turnover** — active/terminated counts, turnover rate, and trends by role,
  filterable by date range and role.
- **Overtime** — OT dollars and hours by role/department for a fixed reporting window.
- **Pay** — current rate distributions, pay trajectories over time for employees with a
  multi-point rate history, and a before/after view of a merit-increase cohort.
- **Market analysis** — compare your org's pay to external benchmarks (state, regional,
  national) you supply.
- **Raise vs. turnover calculator** — model the cost of a raise scenario against estimated
  reduction in turnover, including an optional data-driven estimate if you fit your own
  statistical model (instructions included).

It's one HTML file — open it in any browser, no server, no install, no build step.

## Getting started

1. Download or clone this repo.
2. Open `index.html` in a browser. With no data loaded, every section shows its empty state —
   this confirms the file works before you touch anything.
3. Open `DATA-GUIDE.md` and follow the "Quick start" section to plug in your own export.
4. Reopen `index.html` (or refresh) to see your data.

New to GitHub? See `GITHUB-SETUP.md` for step-by-step instructions to publish this repo from
github.com, with no command line required.

## Files in this repo

| File | Purpose |
|---|---|
| `index.html` | The dashboard itself. Open it directly in a browser. |
| `DATA-GUIDE.md` | How to fill in your own data — every field, every constant, explained. |
| `GITHUB-SETUP.md` | Beginner-friendly guide to publishing this repo on GitHub. |
| `LICENSE` | MIT license. |

## Customizing beyond data

Role names, division groupings, the raise-scenario configuration, and the merit-increase
window are all pulled from named constants near the top of the `<script>` tag in `index.html` —
see `DATA-GUIDE.md` for the full list. You generally don't need to touch chart or calculation
code to adapt the dashboard to your own roles and numbers.

## Privacy note

This dashboard runs entirely in the browser — once you add your own employee data, that data
never leaves the device opening the file (there's no backend, no analytics, no network calls).
If you publish your *filled-in* version anywhere public (including GitHub Pages), remember that
makes it publicly viewable — keep real employee data in a private repo, or keep a public copy
limited to the empty template.

## License

MIT — see `LICENSE`. Use it, modify it, share it, no attribution required (though appreciated).
