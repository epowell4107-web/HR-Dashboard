# Data guide

This dashboard is a single HTML file (`index.html`) with all its data defined as JavaScript
constants near the top of the `<script>` tag. There's no database, no build step, and no backend —
you populate it by editing those constants directly and reopening the file (or re-publishing it).

Open `index.html` in a text editor and search for `/* ============================== DATA ============================== */`
— everything described below lives in that block.

Don't want to hand-edit JavaScript yourself? See the "Fill this in with an AI assistant"
section in `README.md` for a copy-paste prompt that has any AI assistant (Claude, ChatGPT, or
similar) build these constants from your export for you, using this file as the schema.

## Quick start

1. Open `index.html` in a text editor (VS Code, Notepad++, even a plain text editor works).
2. Find `const EMPLOYEES = [];` and replace it with your own array of employee records (shape below).
3. Update `POSITIONS` / `DIVISIONS` / `RESVOC_ROLES` / `ALL_DIRECT_CARE_ROLES` if your roles differ
   from the example set (Residential Staff, IPC, Job Coach, CNA, DDCA, Direct Care Aide, CMA, ACMA, LPN).
4. Update `TODAY`, `DATA_START`, `DATA_END` to match your export's actual dates.
5. Open `index.html` in a browser to check it. Fix anything that looks off, then re-publish.

Everything else (BENCHMARKS, MARKET, ORG_QIDP, SCENARIO_CONFIG, COX_TURNOVER_MODEL, MERIT_WINDOW) is
optional — the dashboard runs fine with those left at their empty/example defaults, just with the
corresponding section showing an empty state or example placeholder instead of real numbers.

## `EMPLOYEES` — the core dataset

An array of one object per employee. This is what almost every section of the dashboard reads from.

```js
const EMPLOYEES = [
  {
    "n":  "Jane Doe",            // name, as you want it displayed
    "p":  "RS",                  // position code -- must be a key in POSITIONS
    "st": "Active",               // "Active" or "Terminated" (exact strings, case-sensitive)
    "r":  15.50,                  // current hourly rate. Use 0 for salaried roles (see "sal" below)
    "h":  "2023-05-17",           // hire date, YYYY-MM-DD
    "rh": null,                   // rehire date, YYYY-MM-DD or null -- used if later than "h"
    "t":  null,                   // termination date, YYYY-MM-DD, or null if still active
    "lp": "2026-03-02",           // date of the employee's most recent rate change, or null
    "pr": 14.50,                  // rate *before* that most recent change, or null if unknown
    "ot": { "ot_dollars": 811.71, "ot_hours": 43.05, "department": "North Campus" }, // or null
    "sal": null                   // annual salary for salaried roles (e.g. IPC); omit or null for hourly roles
  },
  ...
];
```

Notes:
- `p` must match a key in `POSITIONS` (below) — the dashboard filters/groups everything by this code.
- `st`, `h`, `t` drive every headcount, turnover, and tenure calculation. Get these right first;
  everything else is secondary.
- `lp` + `pr` are only used for the merit-increase cohort (see `MERIT_WINDOW` below) — leave both
  `null` for anyone outside that window.
- `ot` is optional per-employee, but when present it should cover the *same* date window for every
  employee (matching `DATA_START`/`DATA_END`) — the Overtime section treats it as one fixed period,
  not something that varies row to row.
- `sal` is for salaried roles only (the dashboard treats a role as salaried if `POSITIONS[code].hourly`
  is `false`).

## `POSITIONS`, `DIVISIONS`, `RESVOC_ROLES`, `ALL_DIRECT_CARE_ROLES` — your role taxonomy

```js
const POSITIONS = {
  RS: { label:'Residential Staff', short:'Residential Staff', division:'res', hourly:true },
  ...
};
```

- Each key is the position code you'll use in `EMPLOYEES[i].p`.
- `division` must be a key in `DIVISIONS` (used to group charts when many roles are selected at once —
  more than ~4-6 individual lines on one chart gets unreadable, so "All roles" groups by division instead).
- `hourly: false` marks a salaried role (its pay is read from `sal`, not `r`).
- `RESVOC_ROLES` and `ALL_DIRECT_CARE_ROLES` are named subsets used by the Pay, Market Analysis, and
  Raise vs. Turnover calculator sections — rename, add, or remove role codes in these arrays to match
  whichever roles you actually want those sections to model. Any role NOT in `ALL_DIRECT_CARE_ROLES`
  (besides your salaried role(s)) simply won't be offered as a calculator scope.

To fully re-theme the role taxonomy for a different industry, edit `POSITIONS`/`DIVISIONS`/
`RESVOC_ROLES`/`ALL_DIRECT_CARE_ROLES` together — they're the only places role codes are defined; every
render function reads through them generically.

## `PAY_HISTORY` — optional multi-point rate ledgers

```js
const PAY_HISTORY = {
  'Jane Doe': [ {d:'2023-10-30', r:13.50}, {d:'2024-10-10', r:13.90}, {d:'2026-03-02', r:15.50} ],
};
```

Keyed by employee name (must match `EMPLOYEES[i].n` exactly). Only add entries for employees where you
actually have more than one data point — most HRIS exports only keep the current rate, so this is
usually a small, manually-curated subset. Ships empty; the "Pay trajectories" card just shows nothing
until you add entries.

## `MERIT_WINDOW` / `MERIT_RAISE_DATE` — the example merit-increase cohort

```js
const MERIT_WINDOW = ['2026-02-20','2026-04-20'];
const MERIT_RAISE_DATE = '2026-03-02';
```

The "Merit increase — before & after" card and the "did the raise help" evidence card both look at
whichever `RS` (or your first `RESVOC_ROLES` entry) employees have an `lp` date inside `MERIT_WINDOW`.
Set these to your own merit round's dates, or to a window with no matching employees to see the
sections' empty states.

## `TODAY`, `DATA_START`, `DATA_END` — your export's dates

```js
const TODAY    = new Date(Date.UTC(2026,7,26));  // "as of" date -- drives tenure/turnover-to-date math
const DATA_END = new Date(Date.UTC(2026,6,31));  // end of your OT export's window
const DATA_START = new Date(Date.UTC(2024,0,1)); // start of your OT export's window, and the "All time" preset's start
```

`RANGES` (the date-range preset buttons, plus the auto-generated month dropdown) is built from
`DATA_START`/`DATA_END` — you don't need to edit `RANGES` itself unless you want different year
buckets than "every full year between `DATA_START` and `DATA_END`, plus the partial year at each end."

## `BENCHMARKS` — generic industry constants

Percentages used by the Raise vs. Turnover calculator (turnover-cost-of-replacement range, employer
FICA rate). These are public, industry-wide figures (cited in the code comments), not org-specific —
reasonable to leave as-is, but worth double-checking against current published sources periodically.

## `MARKET` / `ORG_QIDP` — market analysis benchmarks (optional)

```js
const MARKET = {
  residential: [
    { key:'org', label:'This org', hourly:null, highlight:true },   // leave as-is -- computed live
    { key:'state', label:'Your state', hourly:14.00 },              // add your own rows
  ],
  ipc: { lowHourly:19.85, avgHourly:25.43, highHourly:32.59, avgAnnual:52900 }
};
const ORG_QIDP = { activeN:3, activeAvg:51833, activeLow:47500, activeHigh:57000, allN:19, allAvg:43261 };
```

Ships empty (all `null`/`0`). Add rows to `MARKET.residential` (one per benchmark — a state, a region,
a national figure) and fill in `MARKET.ipc` to enable the salaried-role benchmark comparison.
`ORG_QIDP` is an optional *second* salaried title, for orgs that track more than one management/
professional role separately — rename its labels in the code (search for `IPC` and `QIDP` in
`renderMarket()`) or leave it zeroed to ignore it.

## `SCENARIO_CONFIG` — the custom raise scenario

```js
const SCENARIO_CONFIG = {
  hours: 2080,
  tiers: [
    { roles: ['RS','JC'], raise: 3.00 },
    { roles: ['CNA','DDCA','DCA','CMA','ACMA','LPN'], raise: 2.00 },
  ],
  compressionBenchmarkRole: 'IPC', // or null to skip the "who'd out-earn their manager" check
};
```

Ships with an empty `tiers` array (the section shows a "no scenario configured" placeholder). Add one
entry per raise tier — each tier is a list of role codes and a flat $/hr raise for all of them. Set
`compressionBenchmarkRole` to a salaried role code to compare each tier's new average rate against
that role's pay, or `null` to skip that chart entirely.

## `COX_TURNOVER_MODEL` — optional data-driven "departures avoided" estimate

The Raise vs. Turnover calculator has an optional "Use model estimate" button, driven by a Cox
proportional-hazards survival model relating pay to turnover risk. It ships disabled (`n: 0`) since it
has to be fit on your own data — there's no way to ship a working default here.

To fit your own (Python, using the `lifelines` package):

```python
import pandas as pd
from lifelines import CoxPHFitter

# one row per employee: tenure_years (float), event (1=terminated, 0=still active), rate (current $/hr)
df = pd.DataFrame(...)
cph = CoxPHFitter()
cph.fit(df[['tenure_years','event','rate']], duration_col='tenure_years', event_col='event')
print(cph.summary)  # coef row for "rate" is your betaResidualized; se(coef) is seResidualized
```

Then set in `index.html`:

```js
const COX_TURNOVER_MODEL = {
  n: 145, events: 112, roles: ['RS','JC'],
  betaRaw: 0, seRaw: 0,                       // optional -- only used if you also report a raw-rate version
  betaResidualized: -0.131307, seResidualized: 0.041195,
};
```

The calculator applies `hazard_ratio = exp(betaResidualized * raiseAmount)` and multiplies your
group's current annual departure pace by `(1 - hazard_ratio)`. Full interpretation notes (what a
"residualized" rate covariate is and why it's the more conservative choice) are in `cox_departuresAvoided()`
and the surrounding comments in `index.html`.

## Everything else

Every other function in `index.html` reads from the constants above generically — you shouldn't need
to touch chart-rendering code, filter logic, or the calculator's math to plug in your own data. If a
section looks broken after you add data, it's almost always a data-shape issue (a missing field, a
date in the wrong format, a position code that isn't in `POSITIONS`) rather than something you need to
fix in the rendering code.
