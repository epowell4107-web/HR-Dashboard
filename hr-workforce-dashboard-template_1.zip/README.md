# HR Workforce Dashboard — Template

A single-file, no-backend dashboard for HR teams to see turnover, compensation, and market
positioning at a glance. Built for residential/direct-care style organizations (shift-based
hourly roles plus a few salaried management titles) but adaptable to any hourly workforce.

This repo ships as a **template with no real data in it** — an empty, working example you fill
in with your own export. Nothing here identifies any real organization or employee.

## What it does

- **Headcount & turnover** — active/terminated counts, turnover rate, and trends by role,
  filterable by date range and role.
- **Overtime** — OT dollars and hours by role/department for a fixed reporting window.
- **Pay** — current rate distributions, pay trajectories over time for employees with a
  multi-point rate history, and a before/after view of a merit-increase cohort.
- **Market analysis** — compare your org's pay to external benchmarks (state, regional,
  national) you supply.
- **Raise vs. turnover calculator** — model the cost of a raise scenario against estimated
  reduction in turnover, including an optional data-driven estimate if you fit your own
  statistical model (instructions included).

It's one HTML file — open it in any browser, no server, no install, no build step.

## Getting started

1. Download or clone this repo.
2. Open `index.html` in a browser. With no data loaded, every section shows its empty state —
   this confirms the file works before you touch anything.
3. Open `DATA-GUIDE.md` and follow the "Quick start" section to plug in your own export.
4. Reopen `index.html` (or refresh) to see your data.

New to GitHub? See `GITHUB-SETUP.md` for step-by-step instructions to publish this repo from
github.com, with no command line required.

## Fill this in with an AI assistant

This dashboard is a plain file — it doesn't run any AI itself, and downloading it doesn't
connect you to one. But since all the data lives in a handful of JavaScript constants
described in `DATA-GUIDE.md`, any AI assistant that can read a file and write text (Claude,
ChatGPT, or anything similar) can do the data-entry work for you, instead of you hand-editing
`index.html`.

Open a chat with the assistant of your choice, attach (or paste in) your HR export and
`DATA-GUIDE.md`, and try a prompt like this:

```
I'm setting up an HR dashboard from a GitHub template (index.html). I'm attaching the
data-schema guide for it (DATA-GUIDE.md) and my own HR export (roster and/or overtime report).

Please:
1. Read the schema in DATA-GUIDE.md.
2. Build the EMPLOYEES array (and PAY_HISTORY, if my export has more than one rate per
   person) from my export, matching that schema exactly.
3. Only change POSITIONS/DIVISIONS/RESVOC_ROLES/ALL_DIRECT_CARE_ROLES if my roles differ
   from the example set.
4. Show me the resulting JavaScript to paste into index.html in place of the matching
   constants -- or edit the file directly if you're able to.
5. Ask me if anything is ambiguous (date formats, active vs. terminated, which position code
   a title maps to) instead of guessing.

Separately, for market benchmarks (MARKET / ORG_QIDP in the guide): if you have live web
search, please look up current going hourly rates for [job title(s)] in [city/state/region]
from sources like Indeed, Glassdoor, Salary.com, or the BLS Occupational Employment and Wage
Statistics, and give me a low/average/high range with sources cited so I can review before
adding them. If you can't browse the web, say so and I'll bring my own numbers instead.
```

A couple of things worth knowing about this path: it works with any assistant capable of
reading files and writing text — it isn't specific to Claude — but only an assistant with
live web search can actually look up current market wage data; one without it will either say
so or may guess, so treat any market numbers it gives you as a starting point to verify, not a
final answer. And since your HR export contains real employee data, avoid pasting it into a
chat that isn't private to you, and never paste it into `index.html` before publishing the
repo publicly — see the Privacy note below.

## Files in this repo

| File | Purpose |
|---|---|
| `index.html` | The dashboard itself. Open it directly in a browser. |
| `DATA-GUIDE.md` | How to fill in your own data — every field, every constant, explained. |
| `GITHUB-SETUP.md` | Beginner-friendly guide to publishing this repo on GitHub. |
| `LICENSE` | MIT license. |

## Customizing beyond data

Role names, division groupings, the raise-scenario configuration, and the merit-increase
window are all pulled from named constants near the top of the `<script>` tag in `index.html` —
see `DATA-GUIDE.md` for the full list. You generally don't need to touch chart or calculation
code to adapt the dashboard to your own roles and numbers.

## Privacy note

This dashboard runs entirely in the browser — once you add your own employee data, that data
never leaves the device opening the file (there's no backend, no analytics, no network calls).
If you publish your *filled-in* version anywhere public (including GitHub Pages), remember that
makes it publicly viewable — keep real employee data in a private repo, or keep a public copy
limited to the empty template.

## License

MIT — see `LICENSE`. Use it, modify it, share it, no attribution required (though appreciated).
