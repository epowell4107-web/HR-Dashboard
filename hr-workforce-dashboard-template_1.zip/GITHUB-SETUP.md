# Publishing this repo on GitHub — beginner guide

This walks through putting these files on GitHub entirely through the website — no command
line, no git software to install. It assumes you already have a free GitHub account.

## 1. Create the repository

1. Go to [github.com](https://github.com) and log in.
2. Click the **+** icon in the top-right corner, then **New repository**.
3. Fill in the form:
   - **Repository name** — e.g. `hr-workforce-dashboard`. Letters, numbers, and hyphens only.
   - **Description** (optional) — e.g. "A single-file HR dashboard template for turnover, pay, and market analysis."
   - **Public or Private** — pick **Public** if you want to share it or use the free GitHub
     Pages hosting in step 3 below; pick **Private** if you'd rather keep it visible only to
     you (and anyone you invite).
   - Leave **"Add a README file"** and the other checkboxes **unchecked** — you're uploading
     your own files in the next step.
4. Click **Create repository**.

## 2. Upload the files

1. On your new (empty) repository page, click **uploading an existing file** (it's a link in
   the middle of the page — if you don't see it, click **Add file → Upload files** near the
   top right instead).
2. Drag all four files into the browser window, or click **choose your files** and select them:
   - `index.html`
   - `README.md`
   - `LICENSE`
   - `DATA-GUIDE.md`
   - `GITHUB-SETUP.md` (this file)
3. Scroll down to **"Commit changes"**. You can leave the default message ("Add files via
   upload") or write your own, like "Initial upload".
4. Click **Commit changes**.

That's it — your repository is live on GitHub. Anyone with the link (or anyone, if it's
public) can now see these files, and you can come back and edit or replace them the same way
any time.

## 3. Optional: put the dashboard on a live web page (GitHub Pages)

Since `index.html` is a complete, self-contained page, GitHub can serve it as a real website
for free — no data leaves GitHub's servers beyond what's already in your public repo.

1. In your repository, click **Settings** (top menu bar of the repo, not your account settings).
2. In the left sidebar, click **Pages**.
3. Under **"Build and deployment" → Source**, choose **Deploy from a branch**.
4. Under **Branch**, choose **main** and folder **/ (root)**, then click **Save**.
5. Wait a minute or two, then refresh the page — GitHub will show you the live URL, something
   like `https://your-username.github.io/hr-workforce-dashboard/`.

Only do this with a **public** repository, and only once you're comfortable with whatever data
is in `index.html` being visible to anyone who has that URL — private repos can't use free
GitHub Pages, and a public repo's Pages site is public even if you don't share the link
directly.

## Making changes later

To edit a file (for example, to paste in your own data per `DATA-GUIDE.md`):

1. Open the file in your repository on GitHub and click the pencil (✏️) **Edit** icon in the
   top right of the file view.
2. Make your changes in the browser's text editor.
3. Scroll down and click **Commit changes**.

For bigger changes (or if you're more comfortable editing locally), you can also click
**Add file → Upload files** again and drag in a replacement `index.html` — uploading a file
with the same name overwrites the old one once you commit.

## If something looks wrong

Open `index.html` from your own computer first (double-click it, or drag it into a browser
window) to check it renders correctly *before* uploading — that way you know any issue is in
your data, not in the upload. `DATA-GUIDE.md` has a troubleshooting note at the bottom for
common data-shape issues.
